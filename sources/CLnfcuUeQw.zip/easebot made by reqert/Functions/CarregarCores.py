def cyan():
    return 0x00FFFF

def red():
    return 0xff0000
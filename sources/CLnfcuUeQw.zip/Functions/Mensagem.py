import disnake
from disnake import *

def GerarPersonalizacaoMensagem():
    components = [
        
    ]